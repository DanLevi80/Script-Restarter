fx_version 'cerulean'
game 'gta5'

author 'Dan Levi'
description 'Automatic script restarter for FiveM'
version '1.0.0'

server_script {
    'config.lua',
    'server.lua'
}
